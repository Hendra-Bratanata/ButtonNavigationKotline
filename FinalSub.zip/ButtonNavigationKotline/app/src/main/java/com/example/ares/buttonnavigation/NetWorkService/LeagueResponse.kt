package com.example.ares.buttonnavigation.NetWorkService

import com.example.ares.buttonnavigation.Model.Leagues

data class LeagueResponse(val leagues:List<Leagues>)
package com.example.ares.buttonnavigation.NetWorkService

import com.example.ares.buttonnavigation.Model.Match

data class SearchResponse(val event: List<Match>)
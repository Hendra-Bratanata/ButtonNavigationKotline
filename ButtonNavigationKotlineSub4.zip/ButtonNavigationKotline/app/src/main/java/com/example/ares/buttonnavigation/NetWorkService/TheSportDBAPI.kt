package com.example.ares.buttonnavigation.NetWorkService

import com.example.ares.buttonnavigation.BuildConfig

object TheSportDBAPI {
    fun getPrevMatch(): String {
        return BuildConfig.BASE_URL+
                "api/v1/json/${BuildConfig.TSBD_API_KEY}"+"/eventspastleague.php?id=4328"
    }

    fun getNextMatch(): String {
        return BuildConfig.BASE_URL+
                "api/v1/json/${BuildConfig.TSBD_API_KEY}"+"/eventsnextleague.php?id=4328"
    }
    fun getNextMatchDetail(teamId:String?): String {
        return BuildConfig.BASE_URL+
                "api/v1/json/${BuildConfig.TSBD_API_KEY}"+"/lookupteam.php?id= $teamId"
    }
}
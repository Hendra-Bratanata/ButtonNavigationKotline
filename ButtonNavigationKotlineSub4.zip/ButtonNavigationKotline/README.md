# ButtonNavigationKotline
project bottomNavigation view dengan kotline dan com.example.ares.buttonnavigation.anko layout

project ini menggunakan bahasa kotline dan com.example.ares.buttonnavigation.anko layout
terdapat dua buah tab navigation pada bawah layar utuk memilih request data 
data di ambil dari https://www.thesportsdb.com/api.php 


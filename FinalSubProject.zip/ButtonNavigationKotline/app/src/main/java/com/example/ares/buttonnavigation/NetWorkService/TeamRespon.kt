package com.example.ares.buttonnavigation.NetWorkService

import com.example.ares.buttonnavigation.Model.Team

data class TeamRespon(val teams: List<Team>)
package com.example.ares.buttonnavigation.Utils

interface FetcherListener{
    fun doneFetching()
    fun beginFetching()
}

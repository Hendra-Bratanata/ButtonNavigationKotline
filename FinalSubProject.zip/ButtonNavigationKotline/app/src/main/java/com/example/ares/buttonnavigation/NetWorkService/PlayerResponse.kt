package com.example.ares.buttonnavigation.NetWorkService

import com.example.ares.buttonnavigation.Model.Player

data class PlayerResponse(val player : List<Player>)